model_ac
	:-	def_ac,
		def_thermo,
		def_alarm.
